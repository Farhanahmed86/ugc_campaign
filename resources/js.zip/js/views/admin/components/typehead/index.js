import Typehead from './Typehead.vue'

export {
    Typehead
}