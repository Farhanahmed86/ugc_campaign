<template>



    <div class="panel">
        <h4 style="color:black; margin-left: 30px;">Les créateurs</h4>

        <div class="row" style="padding-top: 10px;">
    <div class="col-8">
    <ul style="display: flex; gap: 20px;">
    <li style="list-style: none;" >
        <button class="buttonss mx-0">
      List
    </button>
    </li>

    <li style="list-style: none;">
        <button class="buttonss mx-0">
      Prevoius Collabration
    </button>
    </li>
    <li style="list-style: none;">
        <button class="buttonss mx-0">
      Blocklist
    </button>
    </li>





</ul>
</div>
<div class="col-4 text-right">
        <button style="background-color: black; color: white; border-radius: 5px; height: 30px; width: 100px;
    ">
                        Newlist
                    </button>
</div>


  </div>
  <div class="container ">
    <div class="col-6">
    <svg xmlns="http://www.w3.org/2000/svg" height="1.5em" viewBox="0 0 512 512" style="margin-right: 10px;"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9c0 0 0 0 0 0C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c0 0-.1-.1-.1-.1c0 0 0 0 0 0c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2c0 0 0 0-.1 .1s0 0-.1 .1l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z"/></svg><span style="font-size: 16px; color: black;">Favorites</span>
</div>
<div class="col-6 text-right">
    <span style="font-size: 16px; color: black;">0 Creators</span>
</div>
</div>



<!-- </div> -->
<div>

   <div class="panel-body ">




<br>















<div class="row">
  <div class="card-container">

    <div class="card">
        <div class="card-image">
            <img src="/images/creator.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
      <div class="image-container ">

        <!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
      </div>
      <div class="content">
        <!-- <div class="category"> Illustration </div> -->
        <div class="row">
            <div class="col-6" style="font-weight: bold; color: black;">Mila Peterson</div>
            <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

        </div>
        <div class="row">
            <div class="col-6" style="font-size: 12px;">Influncer</div>
            <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

        </div>

        <div class="row">
            <div class="col-6" style="font-size: 12px;"><img src="/images/instagram.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
            <div class="col-6 text-right" ><button class="butt">Invite</button></div>

        </div>
        <br>
        <div class="row">
           
        </div>

      </div>
    </div>




    <div class="card">
        <div class="card-image">
            <img src="/images/creator2.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Kemblay Ramos</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/tiktok.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>

    <div class="card">
        <div class="card-image">
            <img src="/images/creator3.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Mila Peterson</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/instagram.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>


    <div class="card">
        <div class="card-image">
            <img src="/images/creator4.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Jhon</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/facebook (1).png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>

    <div class="card">
        <div class="card-image">
            <img src="/images/creator5.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Angela</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/tiktok.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>

    <div class="card">
        <div class="card-image">
            <img src="/images/creator6.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Mila Peterson</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/instagram.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>

    <div class="card">
        <div class="card-image">
            <img src="/images/creator7.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Mila Peterson</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/instagram.png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>
    <div class="card">
        <div class="card-image">
            <img src="/images/creator8.jpg" style="width: 99%;
    border-radius: 20px;">
        </div>
        <div class="image-container ">

<!-- <img src="/images/Ellipse.jpg" alt="Illustration Image"> -->
</div>
<div class="content">
<!-- <div class="category"> Illustration </div> -->
<div class="row">
    <div class="col-6" style="font-weight: bold; color: black;">Margaret</div>
    <!-- <div class="col-6 text-right" style="font-weight: bold; color: black;">$120</div> -->

</div>
<div class="row">
    <div class="col-6" style="font-size: 12px;">Influncer</div>
    <!-- <div class="col-6 text-right" style="font-size: 12px;">Avr.Price</div> -->

</div>

<div class="row">
    <div class="col-6" style="font-size: 12px;"><img src="/images/facebook (1).png" style="width: 20%; margin-right: 2px;" alt="Illustration Image">10.2k like per post</div>
    <div class="col-6 text-right" ><button class="butt">Invite</button></div>

</div>
<br>
<div class="row">
   
</div>

</div>
    </div>
  </div>
</div>






</div>



   </div>

</div>

</template>

<script>

import Vue from 'vue'

    import { get , byMethod} from '../admin/components/lib/api'
    import Typehead from '../admin/components/typehead/Typehead.vue'

export default {
    components: { Typehead },
  data () {
            return {
                selectedOption:'',
                form: {},
                countriesURL:'/api/search/countries',
                aboutURL:'/api/search/about',

                countries:{},
                users_data:{},
                model: {
                    data: []
                }
            }
        },
  name: "Dashboard",


//   beforeRouteEnter(to, from, next) {
//             get('/api/dashboard', to.query)
//                 .then((res) => {
//                     next(vm => vm.setData(res))

//                 })
//         },
//         beforeRouteUpdate(to, from, next) {
//             get('/api/dashboard', to.query)
//                 .then((res) => {
//                     this.setData(res)
//                     next()

//                 })
//         },

        methods: {


            onabout(e) {
                const about = e.target.value
                Vue.set(this.$data.form, 'about', about)
                Vue.set(this.$data.form, 'about_id', about.id)
                Vue.set(this.$data.form, 'about_title', about.title)

            },

            oncountries(e) {
                const countries = e.target.value
                Vue.set(this.$data.form, 'countries', countries)
                Vue.set(this.$data.form, 'countries_id', countries.id)
                Vue.set(this.$data.form, 'countries_title', countries.title)

            },
            detailsPage(item) {
                this.$router.push(`/dashboard/${item.id}`)
            },
            setData(res) {
                Vue.set(this.$data, 'model', res.data.results)
                //this.page = this.model.current_page

                // console.log(res.data)
            },


        }
};
</script>

<style scoped>
.buttons {
    background-color: #ffffff;
 width: 8em;
 height: 3em;
 border-radius: 5px;
 font-size: 12px;
 font-family: inherit;
 border: none;
 position: relative;
 overflow: hidden;
 z-index: 1;
 box-shadow: 4px 4px 8px #c5c5c5,
             -4px -4px 8px #ffffff;

}

.buttonss {
    background-color: #ffffff;
 width: 16em;
 height: 3em;
 border-radius: 5px;
 font-size: 12px;
 font-family: inherit;
 border: none;
 position: relative;
 overflow: hidden;
 z-index: 1;
 box-shadow: 4px 4px 8px #c5c5c5,
             -4px -4px 8px #ffffff;

}

.container {
    margin-top: 20px;
    background-color: #ffffff;
    display: flex;
    align-items: center;
 height: 4em;
 border-radius: 5px;
 font-size: 12px;
 font-family: inherit;
 border: none;
 position: relative;
 overflow: hidden;
 z-index: 1;
 box-shadow: 4px 4px 8px #c5c5c5,
             -4px -4px 8px #ffffff;

}

.buttonsss {
    background-color: #ffffff;
 width: 6em;
 height: 3em;
 border-radius: 5px;
 font-size: 12px;
 font-family: inherit;
 border: none;
 position: relative;
 overflow: hidden;
 z-index: 1;
 box-shadow: 4px 4px 8px #c5c5c5,
             -4px -4px 8px #ffffff;

}
.card-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between; /* Adjust alignment as needed */
  gap: 20px; /* Adjust the gap between cards */
}

.butt{
  border: none;
    color: white;
    background-color: black;
    border-radius: 5px;
    padding: 2px 20px;
}

.card {
  flex: 0 0 calc(25% - 20px); /* Adjust the width (33.33% for 3 cards in a row) and gap */
  background: white;
  padding: .4em;
  border-radius: 24px;
  display: flex;
}

.card-image {
  background-color: rgb(236, 236, 236);
  width: 100%;
  height: 150px;
  border-radius: 12px 12px 0 0;
}
.image-container img {

  width: 100%;
  height: 100%;
 /* Preserve the aspect ratio and cover the container */
}


.card-image:hover {
  transform: scale(0.98);
  cursor: pointer;
}
.content {
  flex-grow: 1;
}

.category {
  text-transform: uppercase;
  font-size: 0.7em;
  font-weight: 600;
  color: rgb(63, 121, 230);
  padding: 10px 7px 0;
}

.category:hover {
  cursor: pointer;
}
.image-container {
  width: 40px; /* Adjust the width of the image container */
  height: 40px; /* Adjust the height of the image container */
  border-radius: 50%; /* Create a rounded shape */
  overflow: hidden;
  margin-right: 10px; /* Adjust the margin between the image and content */
}

.heading {
  font-weight: 600;
  color: rgb(88, 87, 87);
  padding: 7px;
}

.heading:hover {
  cursor: pointer;
}

.author {
  color: gray;
  font-weight: 400;
  font-size: 11px;
  padding-top: 20px;
}

.name {
  font-weight: 600;
}

.name:hover {
  cursor: pointer;
}


</style>
