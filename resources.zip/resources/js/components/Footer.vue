<template>
    <footer class="footer footer-dark bg-dark">
      <div class="container text-center py-5">
        <p>
        Design by 
        </p>
      </div>
    </footer>
</template>

<script>
export default {
    name: 'Footer'
}
</script>